#pragma once
#include"instruments.h"

class Cymbals : public Instruments {
public:
	virtual void Library() {
		Instruments::CymbalsLibrary();
	}
	virtual void PlayNote() {
		while (Note != ';')
		{
			Note = _getche();
			cout << endl;
			system("COLOR 3F");
			Library();
		}
		system("cls");
	}
};