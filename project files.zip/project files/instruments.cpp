#include"instruments.h"

void Instruments::PlayNote() {
	while (Note != ';')
	{
		Note = _getche();
		cout << endl;
		switch (Note)
		{
		case('q'): case('w'): case('e'): case('r'): case('t'): case('y'): system("COLOR 6F"); break;
		case('1'): case('2'): case('3'): case('4'): case('5'): case('6'): system("COLOR 1F"); break;
		case('a'): case('s'): case('d'): case('f'): case('g'): case('h'): system("COLOR 2F"); break;
		case('z'): case('x'): case('c'): case('v'): case('b'): case('n'): system("COLOR 3F"); break;
		case('u'): case('i'): case('o'): case('p'): case('['): case(']'): system("COLOR 4F"); break;
		case('7'): case('8'): case('9'): case('0'): case('-'): case('='): system("COLOR 5F"); break;
		}
		Library();

	}
	system("cls");
}
void Instruments::AcousticGuitarLibrary() {
	switch (Note)
	{
	case('q'):;
		break;
	case('w'):;
		break;
	case('e'):;
		break;
	case('r'):;
		break;
	case('t'):;
		break;
	case('y'):;
		break;
	}
}
void Instruments::ElectricGuitarLibrary() {
	switch (Note)
	{
	case('1'):;
		break;
	case('2'):;
		break;
	case('3'):;
		break;
	case('4'):;
		break;
	case('5'):;
		break;
	case('6'):;
		break;
	}
}
void Instruments::PianoLibrary() {
	switch (Note)
	{
	case('a'):;
		break;
	case('s'):;
		break;
	case('d'):;
		break;
	case('f'):;
		break;
	case('g'):;
		break;
	case('h'):;
		break;
	}
}
void Instruments::CymbalsLibrary() {
	switch (Note)
	{
	case('z'):;
		break;
	case('x'):;
		break;
	case('c'):;
		break;
	case('v'):;
		break;
	case('b'):;
		break;
	case('n'):;
		break;
	}
}
void Instruments::DrumsLibrary() {
	switch (Note)
	{
	case('u'):;
		break;
	case('i'):;
		break;
	case('o'):;
		break;
	case('p'):;
		break;
	case('['):;
		break;
	case(']'):;
		break;
	}
}
void Instruments::FluteLibrary() {
	switch (Note)
	{
	case('7'):;
		break;
	case('8'):;
		break;
	case('9'):;
		break;
	case('0'):;
		break;
	case('-'):;
		break;
	case('='):;
		break;
	}
}