#pragma once
#include"instruments.h"

class Piano : public Instruments {
public:
	virtual void Library() {
		Instruments::PianoLibrary();
	}
	virtual void PlayNote() {
		while (Note != ';')
		{
			Note = _getche();
			cout << endl;
			system("COLOR 2F");
			Library();
		}
		system("cls");
	}
};