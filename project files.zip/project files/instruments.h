#pragma once
#include <iostream>
using namespace std;
#include <conio.h>
#include <windows.h>
#include<stdlib.h>

class Instruments {
protected:
	char Note;
public:
	Instruments() : Note('1') {};
	virtual void PlayNote();
	virtual void Library() {
		AcousticGuitarLibrary();
		ElectricGuitarLibrary();
		PianoLibrary();
		CymbalsLibrary();
		DrumsLibrary();
		FluteLibrary();
	}
	void AcousticGuitarLibrary();
	void ElectricGuitarLibrary();
	void PianoLibrary();
	void CymbalsLibrary();
	void DrumsLibrary();
	void FluteLibrary();
};