#pragma once
#include"instruments.h"

class ElectricGuitar : public Instruments {
public:
	virtual void Library() {
		Instruments::ElectricGuitarLibrary();
	}
	virtual void PlayNote() {
		while (Note != ';')
		{
			Note = _getche();
			cout << endl;
			system("COLOR 1F");
			Library();
		}
		system("cls");
	}
};