#pragma once
#include"instruments.h"

class Drums : public Instruments {
public:
	virtual void Library() {
		Instruments::DrumsLibrary();
	}
	virtual void PlayNote() {
		while (Note != ';')
		{
			Note = _getche();
			cout << endl;
			system("COLOR 4F");
			Library();
		}
		system("cls");
	}
};