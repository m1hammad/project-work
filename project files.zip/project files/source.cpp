#include"instruments.h"
#include"a_guitar.h"
#include"e_guitar.h"
#include"drums.h"
#include"piano.h"
#include"flute.h"
#include"cymbals.h"
#pragma comment(lib,"Winmm.lib")


void main()
{
	system("COLOR 46");
	char ReturnFromScore = '1';
	while (ReturnFromScore == '1') 
	{
		char MenuOption;
		char ReturnFromInstructions;
		char InstrumentChoice = '1';
		char Instrument = '0';
		char type;
		static int Score = 0;
		system("COLOR 46");

		cout << "*** MUSIC MAKER ***\n\nMAKE MUSIC\t\t\t\tSCORE\t\t\tINSTRUCTIONS\t\n(PRESS 1)\t\t\t      (PRESS 2)\t\t\t(PRESS 3)\t\n\t\t\t\t\tEXIT\t\t\t\t\t\n\t\t\t\t\t(PRESS 4)\t\t\t\t\n";

		MenuOption = _getche();
		//Entering and returning from Score Option
		if (MenuOption == '2')
		{
			system("cls");
			system("COLOR 71"); //white background blue text
			cout << "\nSCORE:\t" << Score;
			cout << "\n\nENTER 1 TO RETURN TO MENU\n";
			ReturnFromScore = _getche();
			cout << endl;
			if (ReturnFromScore == '1')
			{
				system("cls");
				continue;
			}
			else
			{
				while (ReturnFromScore != '1')
				{
					cout << "\nCommand not recognized.Enter again:\n";
					ReturnFromScore = _getche();
				}
				system("cls");
				continue;
			}
		}
		//Instructions Option
		if (MenuOption == '3')
		{
			system("cls");
			system("COLOR 71"); //white background lue text
			cout << "Welcome to Music Maker.\nThis program has two options:\n>Play Single Instrument\nand\n>Play Mixed Instruments.\n\nIf you select Single Instrument, you will be able to play only one instrument at a time.\n\nIf you select Mixed Instruments, you will be able to play all the instruments.\n\nFollowing is the detail of seperate instruments and their keys.\n";
			cout << "Acoustic Guitar is played with 'q w e r t y'\nElectric Guitar is played with'1 2 3 4 5 6'\nPiano is played with 'a s d f g h'\nCymbals are played with 'z x c v b n'\nDrums are played with 'u i o p [ ]'\nFlute is played with '7 8 9 0 - ='\n";
			cout << "\n\nENTER 1 TO RETURN TO MENU\n";
			ReturnFromInstructions = _getche();
			if (ReturnFromInstructions == '1')
			{
				system("cls");
				continue;
			}
			else
			{
				while (ReturnFromInstructions != '1')
				{
					cout << "\nCommand not recognized.Enter again:\n";
					ReturnFromInstructions = _getche();
				}
				system("cls");
				continue;
			}

		}
		//Exit Option
		if (MenuOption == '4')
			break;
		if (MenuOption != '1' && MenuOption != '2' && MenuOption != '4' && MenuOption != '3')
		{
			system("cls");
			cout << "WRONG CHOICE! PLEASE ENTER AGAIN.\n";
			continue;
		}
		//Entering Make Music Option
		if (MenuOption == '1')
		{
			while (Instrument = '0')
			{
				system("cls");
				system("COLOR 4F");
				cout << "\nWHAT WOULD YOU LIKE TO PLAY?\n\n";
				cout << ">SINGLE INSTRUMENT\n    (PRESS 1)\n";
				cout << "\n>MIXED INTRUMENTS\n   (PRESS 2)\n";
				cout << "\nIncase you want to go back, press 0\n\n";
				if (InstrumentChoice != '1' && InstrumentChoice != '2' && InstrumentChoice != '0')
					cout << "WRONG CHOICE! PLEASE ENTER AGAIN.\n";
				InstrumentChoice = _getche();



				//Instrument Choice Option
				while (InstrumentChoice != '0')
				{
					if (InstrumentChoice == '1')
					{
						system("cls");
						cout << "\n*YOU SELECTED SINGLE INSTRUMENT*\n\nWHICH INSTRUMENT WOUD YOU LIKE TO PLAY?\n1.ACOUSTC GUITAR\n2.ELECTRIC GUITAR\n3.PIANO\n4.CYMBALS\n5.DRUMS\n6.FLUTE\n\n";
						cout << "Inorder to return to the menu, press 0\nEnter the corresponding number:\t";
						if (Instrument != '1' && Instrument != '2' && Instrument != '3' && Instrument != '4' && Instrument != '5' && Instrument != '6' && Instrument != '0')
							cout << "\nWrong Choice! Please Enter again:\n";
						Instrument = _getche();
						system("cls");
						if (Instrument == '1')
							cout << "\n*YOU SELECTED ACOUSTIC GUITAR*\n";
						if (Instrument == '2')
							cout << "\n*YOU SELECTED ELECTRIC GUITAR*\n";
						if (Instrument == '3')
							cout << "\n*YOU SELECTED  PIANO*\n";
						if (Instrument == '4')
							cout << "\n*YOU SELECTED CYMBALS*\n";
						if (Instrument == '5')
							cout << "\n*YOU SELECTED DRUMS*\n";
						if (Instrument == '6')
							cout << "\n*YOU SELECTED FLUTE*\n";
						if (Instrument == '0')
							break;
						if (Instrument != '1' && Instrument != '2' && Instrument != '3' && Instrument != '4' && Instrument != '5' && Instrument != '6' && Instrument != '0')
						{
							continue;
						}
						cout << "Inorder to return to the menu, press ';'\n\nENTER NOTE TO PLAY:\n*\n";
						break;
					}
					if (InstrumentChoice == '2')
					{
						system("cls");
						cout << "*YOU SELECTED MIXED INSTRUMENTS*\n\nInorder to return to the menu, press ';'\n\nENTER NOTE TO PLAY:\n*\n";
						break;
					}
					if (InstrumentChoice == '0')
					{
						break;
					}
					if (InstrumentChoice != '1' && InstrumentChoice != '2' && InstrumentChoice != '0')
					{
						cout << "WRONG CHOICE! PLEASE ENTER AGAIN.\n";
						break;
					}
				}
				if (Instrument != '1' && Instrument != '2' && Instrument != '3' && Instrument != '4' && Instrument != '5' && Instrument != '6' && Instrument != '0')
					continue;
				if (Instrument == '1' || Instrument == '2' || Instrument == '3' || Instrument == '4' || Instrument == '5' || Instrument == '6')
				{
					break;
				}
				if (InstrumentChoice == '0')
				{
					system("cls");
					break;
				}
				if (InstrumentChoice == '2')
				{
					break;
				}

			}
			if (InstrumentChoice == '0')
			{
				system("cls");
				continue;
			}

			//Playing Music
			Instruments Multiple;
			AcousticGuitar AG;
			ElectricGuitar EG;
			Piano P;
			Cymbals C;
			Drums D;
			Flute F;
			//Acoustic Guitar
			if (Instrument == '1')
			{
				system("COLOR 6F");
				AG.PlayNote();
			}

			//Electric guitar
			if (Instrument == '2')
			{
				system("COLOR 1F");
				EG.PlayNote();
			}
			//Piano
			if (Instrument == '3')
			{
				system("COLOR 2F");
				P.PlayNote();
			}
			//Cymbals
			if (Instrument == '4')
			{
				system("COLOR 3F");
				C.PlayNote();
			}
			//Drums
			if (Instrument == '5')
			{
				system("COLOR 4F");
				D.PlayNote();
			}
			//Flute
			if (Instrument == '6')
			{
				system("COLOR 5F");
				F.PlayNote();
			}
			if (InstrumentChoice == '2')
			{
				Multiple.PlayNote();
			}

		}


	}
	system("cls");

}