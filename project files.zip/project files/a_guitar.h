#pragma once
#include"instruments.h"

class AcousticGuitar : public Instruments {
public:
	virtual void Library() {
		Instruments::AcousticGuitarLibrary();
	}
	virtual void PlayNote() {
		while (Note != ';')
		{
			Note = _getche();
			cout << endl;
			system("COLOR 6F");
			Library();
		}
		system("cls");
	}
};