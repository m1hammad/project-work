#pragma once
#include"instruments.h"

class Flute : public Instruments {
public:
	virtual void Library() {
		Instruments::FluteLibrary();
	}
	virtual void PlayNote() {
		while (Note != ';')
		{
			Note = _getche();
			cout << endl;
			system("COLOR 5F");
			Library();
		}
		system("cls");
	}
};
